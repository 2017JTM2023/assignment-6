###### this is the second .py file ###########

####### write your code here ##########
#the game board

print("Welcome to the Game")
#select the player
player=input("Choose player 1 or player 2\n")

#defining the game board using list
gameboard= [0,1,2,
	    3,4,5,
	    6,7,8]

#function to show the game board
def showboard():
	print gameboard[0],'|',gameboard[1],'|',gameboard[2]
	print "----------"
	print gameboard[3],'|',gameboard[4],'|',gameboard[5]
	print "----------"
	print gameboard[6],'|',gameboard[7],'|',gameboard[8]


showboard()

#loop to select the position
while True:
	position=input("select a spot:")
	position = int (position)	
	 
